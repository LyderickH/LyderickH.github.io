# -*- coding: utf-8 -*-
"""
Génère un jeu de données fictif de suivi budgétaire (Réel vs Budget)
pour une PME multi-services, sur FY2025 (clôturé) + FY2026 (YTD à fin mai).

Sorties (dans RESSOURCES/) :
  - Budget_Reel_vs_Budget.xlsx
      onglets : Budget_2025, Budget_2026 (format PIVOTÉ mensuel, service
                rempli seulement sur la 1re ligne de chaque bloc -> nécessite
                fill down + dépivot, comme décrit dans le programme masterclass)
                + Référentiel_Services, Référentiel_Comptes
  - Comptabilite_2025_2026.xlsx (table transactionnelle prête à l'emploi,
      une ligne par écriture comptable avec fournisseur)
"""
import random
import numpy as np
import pandas as pd
from pathlib import Path

random.seed(42)
np.random.seed(42)

OUT_DIR = Path(__file__).parent / "RESSOURCES"
OUT_DIR.mkdir(parents=True, exist_ok=True)

MOIS_FR = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
           "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"]

# ---------------------------------------------------------------------------
# 1. Référentiels
# ---------------------------------------------------------------------------

SERVICES = [
    (1, "Direction Générale"),
    (2, "Commercial & Ventes"),
    (3, "Marketing"),
    (4, "Production"),
    (5, "Ressources Humaines"),
    (6, "R&D / Bureau d'études"),
    (7, "Logistique & Supply Chain"),
    (8, "Informatique (IT)"),
    (9, "Finance & Administration"),
]
df_services = pd.DataFrame(SERVICES, columns=["SERVICE_ID", "SERVICE"])

# (N_COMPTE, REGROUPEMENT, NATURE_CHARGE)
COMPTES = [
    (606100, "Charges externes", "Fournitures & petit équipement"),
    (613200, "Charges externes", "Locations & charges locatives"),
    (616100, "Charges externes", "Primes d'assurance"),
    (622600, "Charges externes", "Honoraires & conseils"),
    (625100, "Charges externes", "Déplacements & missions"),
    (626100, "Charges externes", "Télécom & affranchissement"),
    (623200, "Charges externes", "Marketing & publicité"),
    (615100, "Charges externes", "Entretien & maintenance"),
    (611000, "Charges externes", "Sous-traitance"),
    (641100, "Charges de personnel", "Salaires & traitements"),
    (645100, "Charges de personnel", "Charges sociales"),
    (601100, "Achats", "Achats matières premières"),
    (601200, "Achats", "Achats fournitures de production"),
]
df_comptes = pd.DataFrame(COMPTES, columns=["N_COMPTE", "REGROUPEMENT", "NATURE_CHARGE"])

# Comptes "communs" à tous les services (charges externes de base + personnel)
COMPTES_COMMUNS = [606100, 613200, 616100, 622600, 625100, 626100, 641100, 645100]
# Marketing & publicité : uniquement Commercial & Ventes (2) et Marketing (3)
COMPTES_MARKETING = {623200: [2, 3]}
# Entretien/maintenance + sous-traitance : Production (4), Logistique (7), IT (8)
COMPTES_TECHNIQUES = {615100: [4, 7, 8], 611000: [4, 7, 8]}
# Achats matières : uniquement Production (4)
COMPTES_ACHATS = {601100: [4], 601200: [4]}

def comptes_actifs_pour_service(service_id):
    actifs = list(COMPTES_COMMUNS)
    for compte, services in {**COMPTES_MARKETING, **COMPTES_TECHNIQUES, **COMPTES_ACHATS}.items():
        if service_id in services:
            actifs.append(compte)
    return actifs

# Budget annuel cible par service pour FY2025 (ordre de grandeur d'une PME, ~14,3 M€ au total)
SERVICE_BUDGET_ANNUEL_2025 = {
    1: 938_600,     # Direction Générale
    2: 1_778_800,   # Commercial & Ventes
    3: 883_400,     # Marketing
    4: 5_515_400,   # Production
    5: 541_000,     # Ressources Humaines
    6: 1_410_200,   # R&D / Bureau d'études
    7: 1_488_000,   # Logistique & Supply Chain
    8: 967_900,     # Informatique (IT)
    9: 757_000,     # Finance & Administration
}

# Poids relatifs "typiques" par nature de charge, utilisés pour répartir le
# budget annuel d'un service entre ses comptes actifs (normalisés à somme=1
# sur les seuls comptes actifs de ce service)
POIDS_NATURE = {
    606100: 1.0,    # Fournitures & petit équipement
    613200: 3.0,    # Locations & charges locatives
    616100: 1.0,    # Primes d'assurance
    622600: 4.5,    # Honoraires & conseils
    625100: 2.0,    # Déplacements & missions
    626100: 0.8,    # Télécom & affranchissement
    623200: 14.0,   # Marketing & publicité (Commercial/Marketing uniquement)
    615100: 4.0,    # Entretien & maintenance (Prod/Logistique/IT uniquement)
    611000: 6.0,    # Sous-traitance (Prod/Logistique/IT uniquement)
    641100: 38.0,   # Salaires & traitements
    645100: 16.0,   # Charges sociales
    601100: 24.0,   # Achats matières premières (Production uniquement)
    601200: 7.0,    # Achats fournitures de production (Production uniquement)
}

# Saisonnalité mensuelle (moyenne = 1, somme = 12) — légère hausse en fin d'année / creux en été
SAISONNALITE = np.array([0.95, 0.92, 1.00, 0.98, 1.02, 0.90,
                          0.80, 0.78, 1.05, 1.10, 1.15, 1.35])
SAISONNALITE = SAISONNALITE / SAISONNALITE.sum() * 12

# Fournisseurs par nature de charge (le premier = fournisseur "habituel" majoritaire)
FOURNISSEURS = {
    606100: ["Lyreco", "Bruneau", "Office Dépôt"],
    613200: ["Foncière Régionale", "Immo Gestion Est", "SCI Les Ateliers"],
    616100: ["AXA Entreprises", "Generali Pro", "Allianz Business"],
    622600: ["Mazars Conseil", "Deloitte Advisory", "Cabinet Fiducial"],
    625100: ["Hôtel Mercure", "Air France", "Booking Business", "SNCF Pro"],
    626100: ["Orange Business", "SFR Entreprises", "La Poste"],
    623200: ["Google Ads", "LinkedIn Ads", "Agence Kaptif", "Meta Business"],
    615100: ["Clim & Froid Services", "Dalkia Maintenance", "Engie Solutions"],
    611000: ["Manpower Industrie", "Randstad Inhouse", "Adecco BTP"],
    641100: ["Paie interne"],
    645100: ["URSSAF", "Malakoff Humanis"],
    601100: ["ArcelorMittal", "Total Energies Chimie", "Arkema"],
    601200: ["RS Components", "Würth France", "Sonepar"],
}

# ---------------------------------------------------------------------------
# 2. Budget mensuel par service x compte x mois (FY2025 + FY2026)
# ---------------------------------------------------------------------------

def budget_mensuel(service_id, n_compte, annee):
    actifs = comptes_actifs_pour_service(service_id)
    poids_total = sum(POIDS_NATURE[c] for c in actifs)
    part = POIDS_NATURE[n_compte] / poids_total
    # petit bruit multiplicatif pour ne pas avoir une répartition trop mécanique
    jitter = 1 + np.random.uniform(-0.08, 0.08)
    annuel = SERVICE_BUDGET_ANNUEL_2025[service_id] * part * jitter
    if annee == 2026:
        annuel *= 1.025  # légère croissance d'une année sur l'autre
    return (annuel / 12) * SAISONNALITE  # array (12,) pour Jan..Dec, somme = annuel


budget_rows = []  # (SERVICE_ID, N_COMPTE, ANNEE, MOIS_IDX, MONTANT_BUDGET)
for service_id, _ in SERVICES:
    for n_compte in comptes_actifs_pour_service(service_id):
        for annee in (2025, 2026):
            mensuel = budget_mensuel(service_id, n_compte, annee)
            for mois_idx in range(12):
                budget_rows.append((service_id, n_compte, annee, mois_idx, round(mensuel[mois_idx], 2)))

df_budget_full = pd.DataFrame(
    budget_rows, columns=["SERVICE_ID", "N_COMPTE", "ANNEE", "MOIS_IDX", "MONTANT_BUDGET"]
)

# ---------------------------------------------------------------------------
# 3. Comptes à "dérive" volontaire (pour peupler la colonne Analyse des dérives)
#    -> écart positif > 0.2% sur un mois donné, concentré sur un fournisseur
# ---------------------------------------------------------------------------

DERIVES = [
    # (service_id, n_compte, annee, mois_idx (0=Jan), multiplicateur_reel, fournisseur_pic)
    (1, 606100, 2026, 0, 1.25, "Lyreco"),
    (1, 613200, 2026, 0, 1.28, "Foncière Régionale"),
    (1, 625100, 2026, 0, 1.40, "Hôtel Mercure"),
    (1, 641100, 2026, 0, 1.03, "Paie interne"),
    (2, 625100, 2026, 1, 1.60, "Booking Business"),
    (2, 641100, 2026, 1, 1.04, "Paie interne"),
    (3, 625100, 2026, 2, 1.70, "Air France"),
    (4, 615100, 2026, 3, 1.55, "Clim & Froid Services"),
    (4, 601100, 2026, 4, 1.03, "ArcelorMittal"),
    (7, 611000, 2026, 1, 1.35, "Manpower Industrie"),
    (8, 626100, 2026, 3, 1.45, "Orange Business"),
    (9, 622600, 2026, 4, 1.30, "Mazars Conseil"),
]
DERIVES_LOOKUP = {(s, c, a, m): (mult, fourn) for s, c, a, m, mult, fourn in DERIVES}

# ---------------------------------------------------------------------------
# 4. Comptabilité (transactions réelles, avec ventilation fournisseur)
#    FY2025 : 12 mois complets. FY2026 : Janvier -> Mai (clôture 31/05/2026).
# ---------------------------------------------------------------------------

def jours_du_mois(annee, mois_idx):
    mois = mois_idx + 1
    if mois == 12:
        prochain = pd.Timestamp(year=annee + 1, month=1, day=1)
    else:
        prochain = pd.Timestamp(year=annee, month=mois + 1, day=1)
    debut = pd.Timestamp(year=annee, month=mois, day=1)
    return (prochain - debut).days

compta_rows = []  # SERVICE_ID, N_COMPTE, DATE, MONTANT_HT, FOURNISSEUR

for _, brow in df_budget_full.iterrows():
    annee = int(brow["ANNEE"])
    mois_idx = int(brow["MOIS_IDX"])
    if annee == 2026 and mois_idx > 4:
        continue  # pas encore clôturé au-delà de mai 2026

    service_id = int(brow["SERVICE_ID"])
    n_compte = int(brow["N_COMPTE"])
    budget_mois = float(brow["MONTANT_BUDGET"])

    key = (service_id, n_compte, annee, mois_idx)
    if key in DERIVES_LOOKUP:
        mult, fournisseur_pic = DERIVES_LOOKUP[key]
    else:
        # bruit normal, petites variations +/- ~0.6%
        mult = 1 + np.random.normal(0, 0.006)
        fournisseur_pic = None

    montant_mois = budget_mois * mult
    fournisseurs = FOURNISSEURS[n_compte]
    nb_jours = jours_du_mois(annee, mois_idx)

    if n_compte == 641100:
        # Salaires : une seule écriture "Paie interne" le dernier jour du mois
        compta_rows.append((service_id, n_compte,
                             pd.Timestamp(annee, mois_idx + 1, min(28, nb_jours)),
                             round(montant_mois, 2), "Paie interne"))
        continue

    # Répartir le montant du mois sur 1 à 4 écritures/fournisseurs
    nb_ecritures = 1 if n_compte in (601100, 601200) else random.randint(2, 4)

    if fournisseur_pic:
        # Le fournisseur en pic capte la part supplémentaire + une part normale
        part_normale = budget_mois / max(nb_ecritures, 1)
        montant_pic = montant_mois - part_normale * (nb_ecritures - 1)
        parts = [montant_pic] + [part_normale] * (nb_ecritures - 1)
        fourn_choisis = [fournisseur_pic] + [
            f for f in random.sample(fournisseurs, min(len(fournisseurs), nb_ecritures - 1))
            if f != fournisseur_pic
        ][: nb_ecritures - 1]
        while len(fourn_choisis) < nb_ecritures:
            fourn_choisis.append(random.choice(fournisseurs))
    else:
        poids = np.random.dirichlet(np.ones(nb_ecritures) * 3)
        parts = montant_mois * poids
        fourn_choisis = [random.choice(fournisseurs) for _ in range(nb_ecritures)]

    for part, fournisseur in zip(parts, fourn_choisis):
        jour = random.randint(1, nb_jours)
        compta_rows.append((service_id, n_compte, pd.Timestamp(annee, mois_idx + 1, jour),
                             round(float(part), 2), fournisseur))

df_compta = pd.DataFrame(
    compta_rows, columns=["SERVICE_ID", "N_COMPTE", "DATE", "MONTANT_HT", "FOURNISSEUR"]
).sort_values(["DATE", "SERVICE_ID", "N_COMPTE"]).reset_index(drop=True)

# ---------------------------------------------------------------------------
# 5. Construire les onglets Budget_2025 / Budget_2026 au format PIVOTÉ,
#    fidèle au programme masterclass (service rempli seulement en 1re ligne
#    du bloc -> nécessite un "fill down" + dépivot dans Power Query)
# ---------------------------------------------------------------------------

def build_pivoted_sheet(annee):
    sub = df_budget_full[df_budget_full["ANNEE"] == annee]
    wide = sub.pivot_table(index=["SERVICE_ID", "N_COMPTE"], columns="MOIS_IDX",
                            values="MONTANT_BUDGET", aggfunc="sum")
    wide = wide.reindex(columns=range(12))
    wide.columns = MOIS_FR
    wide = wide.round(2).reset_index()

    # Joindre le libellé service pour readibilité humaine (comme un vrai export)
    wide = wide.merge(df_services, on="SERVICE_ID", how="left")
    wide = wide.rename(columns={"SERVICE_ID": "SERVICE_ID_TMP"})
    wide = wide.sort_values(["SERVICE_ID_TMP", "N_COMPTE"]).reset_index(drop=True)

    # Ne garder le nom du service que sur la 1re ligne de chaque bloc SERVICE
    service_col = []
    last_service = None
    for sid in wide["SERVICE_ID_TMP"]:
        label = df_services.loc[df_services.SERVICE_ID == sid, "SERVICE"].iloc[0]
        if sid != last_service:
            service_col.append(label)
            last_service = sid
        else:
            service_col.append(None)
    wide["SERVICE"] = service_col

    cols = ["SERVICE", "N_COMPTE"] + MOIS_FR
    return wide[cols]


budget_2025_sheet = build_pivoted_sheet(2025)
budget_2026_sheet = build_pivoted_sheet(2026)

# ---------------------------------------------------------------------------
# 6. Écriture des fichiers Excel / CSV
# ---------------------------------------------------------------------------

xlsx_path = OUT_DIR / "Budget_Reel_vs_Budget.xlsx"
with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
    budget_2025_sheet.to_excel(writer, sheet_name="Budget_2025", index=False)
    budget_2026_sheet.to_excel(writer, sheet_name="Budget_2026", index=False)
    df_services.to_excel(writer, sheet_name="Référentiel_Services", index=False)
    df_comptes.to_excel(writer, sheet_name="Référentiel_Comptes", index=False)

compta_path = OUT_DIR / "Comptabilite_2025_2026.xlsx"
with pd.ExcelWriter(compta_path, engine="openpyxl") as writer:
    df_compta.to_excel(writer, sheet_name="Comptabilite", index=False)

# CSV de secours / relecture rapide
df_compta.to_csv(OUT_DIR / "Comptabilite_2025_2026.csv", index=False, encoding="utf-8-sig")
df_services.to_csv(OUT_DIR / "Referentiel_Services.csv", index=False, encoding="utf-8-sig")
df_comptes.to_csv(OUT_DIR / "Referentiel_Comptes.csv", index=False, encoding="utf-8-sig")

print("Fichiers générés dans", OUT_DIR)
print(" -", xlsx_path.name, "| Budget_2025:", budget_2025_sheet.shape,
      "| Budget_2026:", budget_2026_sheet.shape)
print(" -", compta_path.name, "| lignes:", len(df_compta))
print(" - Total budget FY25:", round(df_budget_full[df_budget_full.ANNEE == 2025].MONTANT_BUDGET.sum()), "EUR")
print(" - Total budget FY26 (12 mois):", round(df_budget_full[df_budget_full.ANNEE == 2026].MONTANT_BUDGET.sum()), "EUR")
print(" - Total réel comptabilisé:", round(df_compta.MONTANT_HT.sum()), "EUR")
