import json

SERVICES = [
    "Direction Générale", "Commercial & Ventes", "Marketing", "Production",
    "Ressources Humaines", "R&D / Bureau d'études", "Logistique & Supply Chain",
    "Informatique (IT)", "Finance & Administration",
]

REGROUPEMENTS_PAR_SERVICE = {
    "Production": ["Charges externes", "Charges de personnel", "Achats"],
}
DEFAULT_REGROUPEMENTS = ["Charges externes", "Charges de personnel"]


def literal(value):
    escaped = value.replace("'", "''")
    return {"identityValues": [{"Literal": {"Value": f"'{escaped}'"}}], "isToggled": True}


children = []
for service in SERVICES:
    node = literal(service)
    regroupements = REGROUPEMENTS_PAR_SERVICE.get(service, DEFAULT_REGROUPEMENTS)
    node["children"] = [literal(r) for r in regroupements]
    children.append(node)

with open(r"C:\Users\lydérick\Desktop\Powerbi\SuiviBudgetaire\expansion_children.json", "w", encoding="utf-8") as f:
    json.dump(children, f, ensure_ascii=False, indent=2)

